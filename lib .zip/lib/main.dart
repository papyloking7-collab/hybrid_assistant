import 'package:flutter/material.dart';

void main() {
  runApp(const HybridAssistant());
  }

  class HybridAssistant extends StatelessWidget {
    const HybridAssistant({super.key});

      @override
        Widget build(BuildContext context) {
            return MaterialApp(
                  debugShowCheckedModeBanner: false,
                        title: 'Hybrid Assistant',
                              theme: ThemeData.dark(),
                                    home: const HomeScreen(),
                                        );
                                          }
                                          }

                                          class HomeScreen extends StatefulWidget {
                                            const HomeScreen({super.key});

                                              @override
                                                State<HomeScreen> createState() => _HomeScreenState();
                                                }

                                                class _HomeScreenState extends State<HomeScreen> {
                                                  final controller = TextEditingController();
                                                    String reply = '';

                                                      void respond() {
                                                          setState(() {
                                                                if (controller.text.toLowerCase().contains('hello')) {
                                                                        reply = 'Hello 👋 I am your assistant';
                                                                              } else {
                                                                                      reply = 'You said: ${controller.text}';
                                                                                            }
                                                                                                  controller.clear();
                                                                                                      });
                                                                                                        }

                                                                                                          @override
                                                                                                            Widget build(BuildContext context) {
                                                                                                                return Scaffold(
                                                                                                                      appBar: AppBar(title: const Text('Hybrid Assistant')),
                                                                                                                            body: Padding(
                                                                                                                                    padding: const EdgeInsets.all(16),
                                                                                                                                            child: Column(
                                                                                                                                                      children: [
                                                                                                                                                                  TextField(
                                                                                                                                                                                controller: controller,
                                                                                                                                                                                              decoration: const InputDecoration(
                                                                                                                                                                                                              hintText: 'Type something...'
                                                                                                                                                                                                                            ),
                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                    const SizedBox(height: 12),
                                                                                                                                                                                                                                                                ElevatedButton(
                                                                                                                                                                                                                                                                              onPressed: respond,
                                                                                                                                                                                                                                                                                            child: const Text('Send'),
                                                                                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                                                                                    const SizedBox(height: 20),
                                                                                                                                                                                                                                                                                                                                Text(reply),
                                                                                                                                                                                                                                                                                                                                          ],
                                                                                                                                                                                                                                                                                                                                                  ),
                                                                                                                                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                              }